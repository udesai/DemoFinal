﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace DemoB.App.Business.Interface
{
   public interface IMergeProducts
    {
        DataTable FindnMergeProducts();
    }
}

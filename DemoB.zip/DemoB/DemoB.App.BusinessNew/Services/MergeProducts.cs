﻿using DemoB.App.Business.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace DemoB.App.Business.Services
{
   public class MergeProducts : IMergeProducts
    {
        private DataTable _dtBarCodesA = null;
        private DataTable _dtBarCodesB = null;

        private DataTable _dtCatalogA = null;
        private DataTable _dtCatalogB = null;

        private DataTable _dtSupplierA = null;
        private DataTable _dtSupplierB = null;
        public MergeProducts()
        {

        }
        public MergeProducts(DataTable dtBarCodesA, DataTable dtBarCodesB, DataTable dtCatalogA, 
            DataTable dtCatalogB, DataTable dtSupplierA, DataTable dtSupplierB)
        {
            this._dtBarCodesA = dtBarCodesA;
            this._dtBarCodesB = dtBarCodesB;

            this._dtCatalogA = dtCatalogA;
            this._dtCatalogB = dtCatalogB;

            this._dtSupplierA = dtSupplierA;
            this._dtSupplierB = dtSupplierB;

        }

        DataTable IMergeProducts.FindnMergeProducts()
        {
            DataTable mergedTable = createTable();
            
            string barcode = string.Empty;
            string sku = string.Empty;
            string descriptionA = string.Empty;
           
            try
            {
              
                //check records for catalogue A
                for (int i = 0; i < _dtBarCodesA.Rows.Count - 1; i++)
                {
                     barcode = _dtBarCodesA.Rows[i][2].ToString();
                     sku = _dtBarCodesA.Rows[i][1].ToString();
                     descriptionA = getSkuDescriptionForBarCode(sku, _dtCatalogA);
                    

                    DataRow[] filteredRows = _dtBarCodesB.Select("Barcode LIKE '%" + barcode + "%'");

                    if (filteredRows.Length > 0)
                    {
                        
                        DataRow[] checkRecordPresent = mergedTable.Select("Sku LIKE '%" + sku + "%'");
                        DataRow[] checkBarcodePresent = mergedTable.Select("Barcode LIKE '%" + barcode + "%'");

                        if (checkRecordPresent.Length ==0 && checkBarcodePresent.Length == 0)
                        {
                            
                            mergedTable.Rows.Add(sku, descriptionA, "A",barcode);

                        }
                    }

                    else
                    {
                       
                        DataRow[] checkRecordPresentMerge = mergedTable.Select("Sku LIKE '%" + sku + "%'");
                        if (checkRecordPresentMerge.Length ==0)
                        {
                            mergedTable.Rows.Add(sku, descriptionA, "A", barcode);
                          
                        }
                        

                    }
                }


                //check records for catalogue B
                for (int i = 0; i < _dtBarCodesB.Rows.Count - 1; i++)
                {
                    barcode = _dtBarCodesB.Rows[i][2].ToString();
                    sku = _dtBarCodesB.Rows[i][1].ToString();
                    descriptionA = getSkuDescriptionForBarCode(sku, _dtCatalogB);

                    DataRow[] filteredRows = _dtBarCodesA.Select("Barcode LIKE '%" + barcode + "%'");

                   
                    if (filteredRows.Length ==0) //else
                    {
                        DataRow[] checkRecordPresentMerge = mergedTable.Select("Sku LIKE '%" + sku + "%'");

                        if (checkRecordPresentMerge.Length == 0)
                        {
                            mergedTable.Rows.Add(sku, descriptionA, "B", barcode);

                         
                        }


                    }
                }
                return mergedTable;
            }
            catch (Exception ex)
            {
                throw ex;
            }
           
        }


        #region P R I V A T E  M E T H O D S 
        private string getSkuDescriptionForBarCode(string sku, DataTable dt)
        {
            string strDescription = string.Empty;

            DataRow[] findRow = dt.Select("Sku LIKE '%" + sku + "%'");

            if (findRow.Length > 0)
            {
                strDescription = findRow[0][1].ToString();
            }
            return strDescription;
        }
        private DataTable createTable()
        {
            DataTable mergedTable = new DataTable();
            mergedTable.Columns.Add("Sku", typeof(String));
            mergedTable.Columns.Add("Description", typeof(String));
            mergedTable.Columns.Add("Source", typeof(String));
            mergedTable.Columns.Add("Barcode", typeof(String));

            return mergedTable;
        } 
        #endregion

    }
}

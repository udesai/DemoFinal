﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using App.Data.Interfaces;
using App.Data.Services;
using DemoB.App.Business.Interface;
using DemoB.App.Business.Services;
using DemoB.App.Data;

namespace DemoB.App
{
    class Program
    {

        static string strFileNameBarCodesA = string.Empty;
        static string strFileNameBarCodesB = string.Empty;
        static string strFileNameCatalogA = string.Empty;
        static string strFileNameCatalogB = string.Empty;
        static string strFileNameSupplierA = string.Empty;
        static string strFileNameSupplierB = string.Empty;

        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        static void Main(string[] args)
        {

            try
            {
              
                ReadExcelServices readXL = null;
                IWriteToCSV write = null;
                strFileNameBarCodesA = "./input/barcodesA.csv";
                strFileNameBarCodesB = "./input/barcodesB.csv";

                strFileNameCatalogA = "./input/catalogA.csv";
                strFileNameCatalogB = "./input/catalogB.csv";

                strFileNameSupplierA = "./input/suppliersA.csv";
                strFileNameSupplierB = "./input/suppliersB.csv";
                Console.WriteLine("\n\n\n Checking the input files...");

                if (CheckFilesExists())
                {

                    
                    log.Info("Reading excel files");

                    readXL = new ReadExcelServices();
                    var dtBarCodesA = readXL.ReadExcel(strFileNameBarCodesA);
                    var dtBarCodesB = readXL.ReadExcel(strFileNameBarCodesB);

                    var dtCatalogA = readXL.ReadExcel(strFileNameCatalogA);
                    var dtCatalogB = readXL.ReadExcel(strFileNameCatalogB);

                    var dtSupplierA = readXL.ReadExcel(strFileNameSupplierA);
                    var dtSupplierB = readXL.ReadExcel(strFileNameSupplierB);

                    IMergeProducts merge = new MergeProducts(dtBarCodesA, dtBarCodesB, dtCatalogA,
                        dtCatalogB, dtSupplierA, dtSupplierB);

                    log.Info("Merging products");

                    DataTable result = merge.FindnMergeProducts();
                    Console.WriteLine("\n\n\n Merge completed\n\n\nExporting data now. Please wait...");
                    log.Info("Merging completed");

                    log.Info("Exporting excel files");

                    if (result != null && result.Rows.Count > 0)
                    {
                        write = new WriteToCSVServices(ref result, "./output/result_output.csv");
                        bool res = write.WriteToCSV();
                        if (res)
                        {
                            Console.WriteLine("\n\n\n Final products CSV file is available in .\\Debug\\output\\result_output.result.csv !!");

                            Console.WriteLine("\n\n\n Product records merged succesfully!! Press enter key to continue...");
                            log.Info("Exporting excel files completed");

                        }
                        else
                        {
                            Console.WriteLine("\n\n\n Error while exporting to CSV file!! Press enter key to continue...");
                            log.Info("Error excel files completed");

                        }

                    }
                    else
                        Console.WriteLine("No records to create CSV!");

                }
                else
                    Console.WriteLine("Please make sure all the necessary files present in input folder!");

                Console.ReadLine();
            }
            catch (Exception ex)
            {
                //Console.WriteLine(ex.Message);
                log.Error("Error Message: " + ex.Message.ToString(), ex);
               Console.ReadLine();
            }
        }

        #region P R I V A T E  M E T H O D S 

        private static bool CheckFilesExists()
        {
            var res = false;

            if (File.Exists(strFileNameBarCodesA) &&
                 File.Exists(strFileNameBarCodesB) &&
                 File.Exists(strFileNameCatalogA) &&
                 File.Exists(strFileNameCatalogB) &&
                 File.Exists(strFileNameSupplierA) &&
                 File.Exists(strFileNameSupplierB)
               )
            {
                res = true;
            }
            else
            {
                res = false;
            }



            return res;
        }

        #endregion

    }
}

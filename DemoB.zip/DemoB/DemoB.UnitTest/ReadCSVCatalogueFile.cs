﻿using System;
using System.Threading.Tasks;
using DemoB.App.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DemoB.UnitTest
{
    [TestClass]
    public class ReadCSVCatalogueFile
    {
        ReadExcelServices readXL = null;
        public ReadCSVCatalogueFile()
        {
            
           //readXL = new ReadExcelServices();
           
        }
        [TestMethod]
        public void ReadCSVCatalogAFile()
        {
            Task.Delay(2 * 1000);
            ReadExcelServices readXL = new ReadExcelServices();
            var dtBarCodesA = readXL.ReadExcel("./input/catalogA.csv");

            Assert.IsNotNull(dtBarCodesA);
        }

        [TestMethod]
        public void ReadCSVCatalogBFile()
        {
            Task.Delay(2 * 1000);
            ReadExcelServices readXL = new ReadExcelServices();
            var dtBarCodesA = readXL.ReadExcel("./input/catalogB.csv");

            Assert.IsNotNull(dtBarCodesA);
        }
    }
}

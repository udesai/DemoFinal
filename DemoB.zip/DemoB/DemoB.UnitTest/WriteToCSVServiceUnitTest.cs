﻿using System;
using System.Data;
using System.Threading.Tasks;
using App.Data.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DemoB.UnitTest
{
    [TestClass]
    public class WriteToCSVServiceUnitTest
    {
        public WriteToCSVServiceUnitTest()
        {
            Task.Delay(10000);

        }
        [TestMethod]
        public void WriteEmptyDtToCSV()
        {
            DataTable dt = createMockData();
            var write = new WriteToCSVServices(ref dt, "./output/result_output.csv");
            bool res = false;
            res =  write.WriteToCSV();
            Assert.IsFalse(res);
        }

        [TestMethod]
        public void WriteDataToCSV()
        {
            DataTable dt = CreateMockOrdersTable();
            
            var write = new WriteToCSVServices(ref dt, "./output/result_output.csv");
            bool res = false;
            
            res = write.WriteToCSV();

          
            Assert.IsTrue(res);
        }
        private DataTable createMockData() {

            var dtMock = new DataTable();

            return dtMock;
        }

        // Create Orders table
        private DataTable CreateMockOrdersTable()
        {
            // Create a DataTable
            DataTable ordersTable = new DataTable("Orders");
            DataColumn dtColumn;
            DataRow dtRow;

            // Create OrderId column
            dtColumn = new DataColumn();
           // dtColumn.DataType = Type.GetType("System.Int32");
            dtColumn.ColumnName = "OrderId";
            dtColumn.AutoIncrement = true;
            dtColumn.Caption = "Order ID";
            dtColumn.ReadOnly = true;
            dtColumn.Unique = true;
            ordersTable.Columns.Add(dtColumn);

            // Create Name column.
            dtColumn = new DataColumn();
            //dtColumn.DataType = Type.GetType("System.String");
            dtColumn.ColumnName = "Name";
            dtColumn.Caption = "Item Name";
            ordersTable.Columns.Add(dtColumn);

            // Create CustId column which Reprence Cust Id from
            // The cust Table
            dtColumn = new DataColumn();
            //dtColumn.DataType = Type.GetType("System.Int32");
            dtColumn.ColumnName = "CustId";
            dtColumn.AutoIncrement = false;
            dtColumn.Caption = "CustId";
            dtColumn.ReadOnly = false;
            dtColumn.Unique = false;
            ordersTable.Columns.Add(dtColumn);

            // Create Description column.
            dtColumn = new DataColumn();
           // dtColumn.DataType = Type.GetType("System.String");
            dtColumn.ColumnName = "Description";
            dtColumn.Caption = "DescriptionName";
            ordersTable.Columns.Add(dtColumn);

           

            // ADD two rows to the customer Id 1001
            dtRow = ordersTable.NewRow();
            dtRow["OrderId"] = 0;
            dtRow["Name"] = "Test Book";
            dtRow["custId"] = 1001;
            dtRow["Description"] = "Same Day";
            ordersTable.Rows.Add(dtRow);
            dtRow = ordersTable.NewRow();
            dtRow["OrderId"] = 1;
            dtRow["Name"] = " My Book";
            dtRow["custId"] = 1001;
            dtRow["description"] = "2 DAY AIR";
            ordersTable.Rows.Add(dtRow);
            // Add two rows to Customer id 1002
            dtRow = ordersTable.NewRow();
            dtRow["OrderId"] = 2;
            dtRow["Name"] = "Data Quest";
            dtRow["Description"] = "Monthly magazine";
            dtRow["CustId"] = 1002;
            ordersTable.Rows.Add(dtRow);
            dtRow = ordersTable.NewRow();
            dtRow["OrderId"] = 3;
            dtRow["Name"] = "PC Magazine";
            dtRow["Description"] = "Monthly Magazine";
            dtRow["CustId"] = 1003;
            ordersTable.Rows.Add(dtRow);
            // Add two rows to Customer id 1003
            dtRow = ordersTable.NewRow();
            dtRow["OrderId"] = 4;
            dtRow["Name"] = "PCMagazine";
            dtRow["Description"] = "Monthly Magazine";
            dtRow["custId"] = 1003;
            ordersTable.Rows.Add(dtRow);
            dtRow = ordersTable.NewRow();
            dtRow["OrderId"] = 5;
            dtRow["Name"] = "A Book";
            dtRow["CustId"] = 1003;
            dtRow["Description"] = "XYZ";
            ordersTable.Rows.Add(dtRow);

            return ordersTable;
        }
    }
}

﻿using System;
using DemoB.App.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DemoB.UnitTest
{
    [TestClass]
    public class ReadCSV
    {
        ReadExcelServices readXL = null;
        public ReadCSV()
        {
            //readXL = new ReadExcelServices();
        }
       [TestMethod]
        public void ReadCSVEmptyFilePath()
        {
            ReadExcelServices readXL = new ReadExcelServices();
            var dtBarCodesA = readXL.ReadExcel("");

            Assert.IsNull(dtBarCodesA);
        }

     

    }
}

﻿using System;
using System.Threading.Tasks;
using DemoB.App.Data;
using DemoB.App.Data.Interfaces;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DemoB.UnitTest
{
    [TestClass]
    public class ReadCSVBarcodesFile
    {

       
        public ReadCSVBarcodesFile()
        {
            
        }
        [TestMethod]
        public void ReadCSVBarcodesAFileTest()
        {
            Task.Delay(2 * 1000);
            ReadExcelServices readXL = new ReadExcelServices();
            var dtBarCodesA = readXL.ReadExcel("./input/barcodesA.csv");

            Assert.IsNotNull(dtBarCodesA);
          
        }
        [TestMethod]
        public void ReadCSVBarcodesBFileTest()
        {
            Task.Delay(2 * 1000);
            ReadExcelServices readXL = new ReadExcelServices();
            var dtBarCodesA = readXL.ReadExcel("./input/barcodesB.csv");

            Assert.IsNotNull(dtBarCodesA);
           
        }

    }
}

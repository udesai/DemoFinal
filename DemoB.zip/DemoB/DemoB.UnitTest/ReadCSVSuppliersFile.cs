﻿using System;
using System.Threading.Tasks;
using DemoB.App.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DemoB.UnitTest
{
    [TestClass]
    public class ReadCSVSuppliersFile
    {
        ReadExcelServices readXL = null;
        public ReadCSVSuppliersFile()
        {
           // readXL = new ReadExcelServices();
        }
     
        [TestMethod]
        public void ReadCSVSuppliersAFileTest()
        {
            Task.Delay(2 * 1000);
            ReadExcelServices readXL = new ReadExcelServices();
            var dtBarCodesA = readXL.ReadExcel("./input/suppliersA.csv");

            Assert.IsNotNull(dtBarCodesA);
        }

        [TestMethod]
        public void ReadCSVSuppliersBFile()
        {
            Task.Delay(2 * 1000);
            ReadExcelServices readXL = new ReadExcelServices();
            var dtBarCodesA = readXL.ReadExcel("./input/suppliersB.csv");

            Assert.IsNotNull(dtBarCodesA);
        }

     
      

    }
}

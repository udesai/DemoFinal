﻿using System;
using System.Data;
using App.Data.Services;
using DemoB.App.Business.Interface;
using DemoB.App.Business.Services;
using DemoB.App.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DemoB.UnitTest
{
    [TestClass]
    public class FindandMergeProductsTest
    {
        [TestMethod]
        public void RunFindnMergeTest()
        {
            string strFileNameBarCodesA = "./input/barcodesA.csv";
            string strFileNameBarCodesB = "./input/barcodesB.csv";

            string strFileNameCatalogA = "./input/catalogA.csv";
            string strFileNameCatalogB = "./input/catalogB.csv";

            string strFileNameSupplierA = "./input/suppliersA.csv";
            string strFileNameSupplierB = "./input/suppliersB.csv";

            var readXL = new ReadExcelServices();
            var dtBarCodesA = readXL.ReadExcel(strFileNameBarCodesA);
            var dtBarCodesB = readXL.ReadExcel(strFileNameBarCodesB);

            var dtCatalogA = readXL.ReadExcel(strFileNameCatalogA);
            var dtCatalogB = readXL.ReadExcel(strFileNameCatalogB);

            var dtSupplierA = readXL.ReadExcel(strFileNameSupplierA);
            var dtSupplierB = readXL.ReadExcel(strFileNameSupplierB);

            IMergeProducts merge = new MergeProducts(dtBarCodesA, dtBarCodesB, dtCatalogA,
                dtCatalogB, dtSupplierA, dtSupplierB);
            DataTable result = merge.FindnMergeProducts();

            if (result != null && result.Rows.Count > 0)
            {
                var write = new WriteToCSVServices(ref result, "./output/result_output.csv");
                bool res = write.WriteToCSV();
                Assert.IsTrue(res);
            }

        }
    }
}

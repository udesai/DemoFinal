﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.Data.Utilities
{
   static class Utility
    {
        public static bool CheckFilesExists(string fileName)
        {
           
            return File.Exists(fileName) ? true:false;
        }
    }
}

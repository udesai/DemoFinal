﻿using App.Data.Utilities;
using DemoB.App.Data.Interfaces;
using ExcelDataReader;
using IronXL;
using System;
using System.Data;
using System.IO;

namespace DemoB.App.Data
{
    public class ReadExcelServices : Interfaces.IReadExcel
    {
        public ReadExcelServices()
        {
        }


        /// <summary>
        /// this method will read the CSV file and copy its data into a datatable
        /// </summary>
        /// <param name="fileName">name of the file</param>
        /// <returns>DataTable</returns>
        public DataTable ReadExcel(string fileName)
        {
            DataTable dtResult = null;
            if (!string.IsNullOrEmpty(fileName))
            {
                if (Utility.CheckFilesExists(fileName))
                {

                    WorkBook workbook = WorkBook.Load(fileName);
                    // Work with a single WorkSheet.
                    //you can pass static sheet name like Sheet1 to get that sheet
                    //WorkSheet sheet = workbook.GetWorkSheet("Sheet1");
                    //You can also use workbook.DefaultWorkSheet to get default in case you want to get first sheet only
                    WorkSheet sheet = workbook.DefaultWorkSheet;
                    //Convert the worksheet to System.Data.DataTable
                    //Boolean parameter sets the first row as column names of your table.

                    dtResult = sheet.ToDataTable(true);
                }
            }
            return dtResult;
        }
    }
}

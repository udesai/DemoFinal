﻿using App.Data.Interfaces;
using IronXL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.Data.Services
{
    public class WriteToCSVServices : IWriteToCSV
    {
        private DataTable _dtResult;

        private string _fileName;
        public WriteToCSVServices(ref DataTable dtResult, string fileName)
        {
            this._dtResult = dtResult;
            this._fileName = fileName;
        }

        public bool WriteToCSV()
        {
            bool res = false;
            WorkBook wb = null;
            try
            {

                if (_dtResult != null && _dtResult.Rows.Count > 0)
                {
                    wb = WorkBook.Create(ExcelFileFormat.XLSX);

                    WorkSheet ws = wb.CreateWorkSheet("result");
                    ws["A" + 1].Value = "SKU";
                    ws["B" + 1].Value = "Description";
                    ws["C" + 1].Value = "Source";

                  

                    int rowCount = 1;
                    foreach (DataRow row in _dtResult.Rows)
                    {

                        ws["A" + (rowCount + 1)].Value = row[0].ToString();
                        ws["B" + (rowCount + 1)].Value = row[1].ToString();
                        ws["C" + (rowCount + 1)].Value = row[2].ToString();
                       

                        rowCount++;
                    }
                    wb.SaveAsCsv(_fileName, ","); //Saved as : 
                    res = true;
                }
                else
                {
                    res = false;
                }

                return res;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (wb !=null)
                {
                    wb.Close();

                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.Data.Models
{
  public class ResultOutput
    {
        private string sKU;
        private string description;
        private string source;

        public string SKU { get => sKU; set => sKU = value; }
        public string Source { get => source; set => source = value; }
        public string Description { get => description; set => description = value; }
    }
}
